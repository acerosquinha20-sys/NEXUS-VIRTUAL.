package com.virtualnexus.app

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts.OpenDocument
import androidx.activity.result.contract.ActivityResultContracts.OpenMultipleDocuments
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

val Bg = Color(0xFF0B0F1A); val Card = Color(0xFF141B2D); val Gold = Color(0xFFFFD700); val Violet = Color(0xFF7C4DFF)
val Red = Color(0xFFFF5252)
val Accents = listOf(Color(0xFF00E5FF), Color(0xFFFFD700), Color(0xFFFF4081), Color(0xFF69F0AE))
val Acc: Color get() = Accents[Prefs.accent]
val Covers = listOf(R.drawable.cover1, R.drawable.cover2, R.drawable.cover3, R.drawable.cover4)
fun cover(g: Game) = Covers[Math.floorMod(g.pkg.hashCode(), Covers.size)]

class MainActivity : ComponentActivity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        setContent { MaterialTheme(colorScheme = darkColorScheme(primary = Acc, background = Bg, surface = Card)) { Root() } }
    }
}

@Composable fun Root() {
    var splash by remember { mutableStateOf(true) }
    LaunchedEffect(Unit) { Fx.play("launch"); delay(2000); splash = false }
    Box(Modifier.fillMaxSize().background(Bg)) { Crossfade(splash, animationSpec = tween(700), label = "s") { if (it) Splash() else Main() } }
}

@Composable fun Splash() {
    val sc = remember { Animatable(0.4f) }; val al = remember { Animatable(0f) }
    LaunchedEffect(Unit) { launch { sc.animateTo(1f, spring(Spring.DampingRatioMediumBouncy)) }; al.animateTo(1f, tween(900)) }
    val glow by rememberInfiniteTransition(label = "g").animateFloat(0.85f, 1.15f, infiniteRepeatable(tween(1000), RepeatMode.Reverse), label = "gg")
    Box(Modifier.fillMaxSize(), Alignment.Center) {
        Box(Modifier.size(260.dp).scale(glow).background(Brush.radialGradient(listOf(Acc.copy(alpha = .35f), Color.Transparent))))
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Image(painterResource(R.drawable.logo), null, Modifier.size(150.dp).scale(sc.value).clip(RoundedCornerShape(36.dp)))
            Spacer(Modifier.height(18.dp))
            Text("VIRTUAL NEXUS", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Color.White, modifier = Modifier.scale(al.value))
            Text("VIP EDITION", fontSize = 14.sp, letterSpacing = 6.sp, color = Gold, modifier = Modifier.scale(al.value))
        }
    }
}

@Composable fun Main() {
    val ctx = LocalContext.current; val scope = rememberCoroutineScope()
    val games = remember { mutableStateListOf<Game>().apply { addAll(Store.load(ctx)) } }
    var busy by remember { mutableStateOf(false) }
    var target by remember { mutableStateOf<String?>(null) }
    var tab by remember { mutableIntStateOf(0) }
    fun persist() = Store.save(ctx, games)
    fun upd(pkg: String, f: (Game) -> Game) { val i = games.indexOfFirst { it.pkg == pkg }; if (i >= 0) { games[i] = f(games[i]); persist() } }
    fun play(g: Game, user: Int = 0) {
        if (Engine.launch(g.pkg, user)) { Fx.play("launch"); upd(g.pkg) { it.copy(launches = it.launches + 1, last = System.currentTimeMillis()) } } else Fx.err(ctx)
    }
    val pickApk = rememberLauncherForActivityResult(OpenDocument()) { uri ->
        uri ?: return@rememberLauncherForActivityResult
        scope.launch { busy = true
            val g = withContext(Dispatchers.IO) { runCatching { Engine.installApk(ctx, uri) }.onFailure { NexusLog.e(it.message ?: "erro") }.getOrNull() }
            if (g != null) { games.removeAll { it.pkg == g.pkg }; games.add(g); persist(); Fx.ok(ctx) } else Fx.err(ctx)
            busy = false }
    }
    val pickObb = rememberLauncherForActivityResult(OpenMultipleDocuments()) { uris ->
        val p = target ?: return@rememberLauncherForActivityResult
        if (uris.isEmpty()) return@rememberLauncherForActivityResult
        scope.launch { busy = true
            val n = withContext(Dispatchers.IO) { runCatching { Engine.addObbs(ctx, p, uris) }.onFailure { NexusLog.e(it.message ?: "erro") }.getOrDefault(0) }
            if (n > 0) { upd(p) { it.copy(obbs = it.obbs + n) }; Fx.ok(ctx) } else Fx.err(ctx)
            busy = false }
    }
    val addGame = { Fx.tap(ctx); pickApk.launch(arrayOf("application/vnd.android.package-archive", "application/octet-stream")) }
    val addObb = { g: Game -> Fx.tap(ctx); target = g.pkg; pickObb.launch(arrayOf("*/*")) }
    LaunchedEffect(Unit) { NexusLog.i("Virtual Nexus VIP pronto") }

    Scaffold(containerColor = Bg, bottomBar = {
        NavigationBar(containerColor = Card) {
            listOf("🏠" to "Início", "🎮" to "Jogos", "📜" to "Logs", "👑" to "VIP").forEachIndexed { i, (ic, l) ->
                NavigationBarItem(tab == i, { Fx.tap(ctx); tab = i }, { Text(ic, fontSize = 20.sp) }, label = { Text(l, fontSize = 11.sp) },
                    colors = NavigationBarItemDefaults.colors(indicatorColor = Acc.copy(alpha = .25f), selectedTextColor = Acc))
            }
        }
    }) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            AnimatedContent(tab, transitionSpec = { fadeIn(tween(250)) togetherWith fadeOut(tween(150)) }, label = "tabs") { t ->
                when (t) {
                    0 -> HomeTab(games, busy, addGame) { play(it) }
                    1 -> GamesTab(games, busy, addGame, addObb, ::play,
                        onFav = { g -> upd(g.pkg) { it.copy(fav = !it.fav) } },
                        onClone = { g -> scope.launch { busy = true
                            val id = withContext(Dispatchers.IO) { runCatching { Engine.clone(ctx, g) }.getOrNull() }
                            if (id != null) { upd(g.pkg) { it.copy(clones = id) }; Fx.ok(ctx) } else Fx.err(ctx); busy = false } },
                        onClear = { g -> Engine.clearData(g.pkg); Fx.ok(ctx) },
                        onRemove = { g -> scope.launch { withContext(Dispatchers.IO) { Engine.remove(ctx, g) }; games.remove(g); persist(); Fx.ok(ctx) } })
                    2 -> LogsTab()
                    else -> VipTab(games)
                }
            }
        }
    }
}

@Composable fun Stat(label: String, value: Int, mod: Modifier) {
    val v by animateIntAsState(value, tween(900), label = "n")
    Column(mod.background(Card, RoundedCornerShape(16.dp)).padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("$v", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Acc); Text(label, fontSize = 12.sp, color = Color.Gray)
    }
}

@Composable fun GameCover(g: Game, mod: Modifier, onClick: () -> Unit) {
    Box(mod.clip(RoundedCornerShape(16.dp)).clickable { onClick() }) {
        Image(painterResource(cover(g)), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xCC000000)))))
        Text(g.name, Modifier.align(Alignment.BottomStart).padding(10.dp), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1)
    }
}

@Composable fun HomeTab(games: List<Game>, busy: Boolean, onAdd: () -> Unit, onPlay: (Game) -> Unit) {
    val pulse by rememberInfiniteTransition(label = "p").animateFloat(1f, if (Prefs.anim) 1.08f else 1f, infiniteRepeatable(tween(1400), RepeatMode.Reverse), label = "pp")
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Box(Modifier.fillMaxWidth().height(240.dp)) {
            Image(painterResource(R.drawable.hero), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Bg))))
            Column(Modifier.align(Alignment.BottomStart).padding(16.dp)) {
                Text("👑 VIP", Modifier.scale(pulse).background(Gold, RoundedCornerShape(8.dp)).padding(horizontal = 10.dp, vertical = 2.dp), color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Text("VIRTUAL NEXUS", fontSize = 30.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
                Text("Seu container de jogos premium", color = Color.LightGray, fontSize = 13.sp)
            }
        }
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Stat("Jogos", games.size, Modifier.weight(1f)); Stat("OBBs", games.sumOf { it.obbs }, Modifier.weight(1f)); Stat("Partidas", games.sumOf { it.launches }, Modifier.weight(1f))
            }
            Button(onAdd, Modifier.fillMaxWidth().height(52.dp), enabled = !busy, colors = ButtonDefaults.buttonColors(containerColor = Violet)) { Text(if (busy) "Processando..." else "＋ ADICIONAR JOGO (APK)", fontWeight = FontWeight.Bold) }
            if (busy) LinearProgressIndicator(Modifier.fillMaxWidth(), color = Acc)
            val favs = games.filter { it.fav }; val recent = games.filter { it.last > 0 }.sortedByDescending { it.last }.take(8)
            if (favs.isNotEmpty()) { Text("⭐ Favoritos", color = Gold, fontWeight = FontWeight.Bold); LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) { items(favs, key = { it.pkg }) { GameCover(it, Modifier.size(170.dp, 100.dp)) { onPlay(it) } } } }
            if (recent.isNotEmpty()) { Text("🕒 Jogados recentemente", color = Acc, fontWeight = FontWeight.Bold); LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) { items(recent, key = { it.pkg }) { GameCover(it, Modifier.size(170.dp, 100.dp)) { onPlay(it) } } } }
            if (games.isEmpty()) Text("Toque em adicionar para colocar seu primeiro jogo.", color = Color.Gray)
        }
    }
}

@Composable fun GamesTab(games: List<Game>, busy: Boolean, onAdd: () -> Unit, onObb: (Game) -> Unit, onPlay: (Game, Int) -> Unit,
                         onFav: (Game) -> Unit, onClone: (Game) -> Unit, onClear: (Game) -> Unit, onRemove: (Game) -> Unit) {
    val ctx = LocalContext.current
    var q by remember { mutableStateOf("") }; var sort by remember { mutableIntStateOf(0) }
    val list = games.filter { it.name.contains(q, true) || it.pkg.contains(q, true) }.let {
        when (sort) { 1 -> it.sortedByDescending { g -> g.last }; 2 -> it.sortedByDescending { g -> g.launches }; else -> it.sortedBy { g -> g.name.lowercase() } } }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth(), placeholder = { Text("🔍 Buscar jogo") }, singleLine = true, shape = RoundedCornerShape(14.dp))
        Row(Modifier.padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Nome", "Recentes", "Mais jogados").forEachIndexed { i, l -> FilterChip(sort == i, { Fx.tap(ctx); sort = i }, { Text(l) }) }
        }
        if (busy) LinearProgressIndicator(Modifier.fillMaxWidth(), color = Acc)
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            if (list.isEmpty()) item { Text("Nenhum jogo encontrado.", color = Color.Gray) }
            items(list, key = { it.pkg }) { g ->
                var open by remember { mutableStateOf(false) }
                Column(Modifier.fillMaxWidth().animateItem().animateContentSize().background(Card, RoundedCornerShape(18.dp))) {
                    Box(Modifier.fillMaxWidth().height(110.dp).clip(RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp))) {
                        Image(painterResource(cover(g)), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xDD000000)))))
                        Text(if (g.fav) "⭐" else "☆", Modifier.align(Alignment.TopEnd).padding(12.dp).clickable { Fx.tap(ctx); onFav(g) }, fontSize = 24.sp, color = Gold)
                        Column(Modifier.align(Alignment.BottomStart).padding(12.dp)) {
                            Text(g.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp, maxLines = 1)
                            Text("${g.obbs} OBB • ${g.perms.size} permissões • ${g.launches} partidas", color = Color.LightGray, fontSize = 11.sp)
                        }
                    }
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button({ Fx.tap(ctx); onPlay(g, 0) }, colors = ButtonDefaults.buttonColors(containerColor = Acc, contentColor = Color.Black)) { Text("▶ JOGAR", fontWeight = FontWeight.Bold) }
                            OutlinedButton({ onObb(g) }) { Text("＋ OBB") }
                            OutlinedButton({ Fx.tap(ctx); onClone(g) }, enabled = !busy) { Text("⧉ Clonar") }
                        }
                        if (g.clones > 0) Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { repeat(g.clones) { i -> AssistChip({ Fx.tap(ctx); onPlay(g, i + 1) }, { Text("Clone ${i + 1}") }) } }
                        Row {
                            TextButton({ Fx.tap(ctx); open = !open }) { Text(if (open) "Ocultar permissões" else "Permissões") }
                            TextButton({ onClear(g) }) { Text("Limpar dados") }
                            TextButton({ onRemove(g) }) { Text("Remover", color = Red) }
                        }
                        if (open) Text(g.perms.joinToString("\n").ifEmpty { "Nenhuma permissão" }, color = Acc, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }
    }
}

fun share(ctx: Context, text: String, title: String) =
    ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, text) }, title))

@Composable fun LogsTab() {
    val ctx = LocalContext.current; val ls = rememberLazyListState()
    LaunchedEffect(NexusLog.lines.size) { if (NexusLog.lines.isNotEmpty()) ls.animateScrollToItem(NexusLog.lines.lastIndex) }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("📜 Console", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Acc)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(vertical = 8.dp)) {
            OutlinedButton({ Fx.tap(ctx); share(ctx, NexusLog.lines.joinToString("\n"), "Compartilhar logs") }) { Text("Compartilhar") }
            OutlinedButton({ Fx.tap(ctx); NexusLog.lines.clear() }) { Text("Limpar") }
        }
        LazyColumn(Modifier.fillMaxSize().background(Color.Black, RoundedCornerShape(14.dp)).padding(10.dp), ls) {
            items(NexusLog.lines) { Text(it, color = if ("ERRO" in it) Red else Color(0xFF69F0AE), fontFamily = FontFamily.Monospace, fontSize = 11.sp) }
        }
    }
}

@Composable fun SwitchRow(label: String, v: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().background(Card, RoundedCornerShape(14.dp)).padding(horizontal = 14.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f), color = Color.White); Switch(v, onChange)
    }
}

@Composable fun VipTab(games: List<Game>) {
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Box(Modifier.fillMaxWidth().background(Brush.horizontalGradient(listOf(Color(0xFF3D2B00), Color(0xFF7A5A00))), RoundedCornerShape(20.dp)).padding(18.dp)) {
            Column { Text("👑 VIP ATIVO", color = Gold, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp); Text("Todos os recursos liberados", color = Color.White, fontSize = 13.sp) }
        }
        Text("Ajustes", color = Acc, fontWeight = FontWeight.Bold)
        SwitchRow("🔊 Sons", Prefs.sound) { Prefs.sound = it; Prefs.save(ctx); Fx.tap(ctx) }
        SwitchRow("📳 Vibração", Prefs.haptic) { Prefs.haptic = it; Prefs.save(ctx); Fx.tap(ctx) }
        SwitchRow("✨ Animações", Prefs.anim) { Prefs.anim = it; Prefs.save(ctx); Fx.tap(ctx) }
        Text("Cor do tema", color = Acc, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Accents.forEachIndexed { i, c -> Box(Modifier.size(44.dp).clip(CircleShape).background(c).border(if (Prefs.accent == i) 3.dp else 0.dp, Color.White, CircleShape)
                .clickable { Prefs.accent = i; Prefs.save(ctx); Fx.tap(ctx) }) }
        }
        Text("Ferramentas", color = Acc, fontWeight = FontWeight.Bold)
        OutlinedButton({ Fx.tap(ctx); share(ctx, Store.json(games), "Backup da biblioteca") }, Modifier.fillMaxWidth()) { Text("💾 Exportar backup da biblioteca") }
        Text("Recursos: clonagem de jogos • favoritos • busca e ordenação • múltiplos OBBs • permissões • limpar dados • logs • sons e vibração • temas.\nVersão 2.0-VIP", color = Color.Gray, fontSize = 12.sp)
    }
}
