package com.virtualnexus.app

import android.app.Application

class NexusApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Prefs.load(this); Fx.init(this)
        NexusLog.i("Versão sem motor de virtualização")
    }
}
