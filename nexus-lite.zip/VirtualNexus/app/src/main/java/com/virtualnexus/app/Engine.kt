package com.virtualnexus.app

import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import java.io.File

object Engine {
    private fun apk(ctx: Context, pkg: String) = File(ctx.filesDir, "apks/$pkg.apk")

    private fun copy(ctx: Context, uri: Uri, dest: File) {
        dest.parentFile?.mkdirs()
        ctx.contentResolver.openInputStream(uri)!!.use { i -> dest.outputStream().use { o -> i.copyTo(o, 64 * 1024) } }
    }

    fun installApk(ctx: Context, uri: Uri): Game? {
        val tmp = File(ctx.cacheDir, "tmp.apk")
        NexusLog.i("Copiando APK...")
        copy(ctx, uri, tmp)
        val pm = ctx.packageManager
        val info = pm.getPackageArchiveInfo(tmp.path, PackageManager.GET_PERMISSIONS)
        if (info == null) { NexusLog.e("APK inválido"); tmp.delete(); return null }
        info.applicationInfo?.sourceDir = tmp.path; info.applicationInfo?.publicSourceDir = tmp.path
        val name = info.applicationInfo?.loadLabel(pm)?.toString() ?: info.packageName
        val perms = info.requestedPermissions?.map { it.substringAfterLast('.') } ?: emptyList()
        val dest = apk(ctx, info.packageName)
        dest.parentFile?.mkdirs(); tmp.copyTo(dest, true); tmp.delete()
        NexusLog.i("Pacote: ${info.packageName} • ${perms.size} permissões")
        NexusLog.ok("$name adicionado à biblioteca (motor de virtualização ausente nesta versão)")
        return Game(name, info.packageName, perms)
    }

    /** Cria uma cópia isolada do jogo (outra conta/save). Retorna o id do clone. */
    fun clone(ctx: Context, g: Game): Int? {
        val id = g.clones + 1
        NexusLog.ok("Clone $id de ${g.name} criado"); return id
    }

    fun addObbs(ctx: Context, pkg: String, uris: List<Uri>): Int {
        val dir = File(ctx.getExternalFilesDir(null), "obb/$pkg")
        uris.forEach { u ->
            val n = ctx.contentResolver.query(u, null, null, null, null)?.use { c ->
                val i = c.getColumnIndex("_display_name"); if (c.moveToFirst() && i >= 0) c.getString(i) else null
            } ?: "main.obb"
            NexusLog.i("Copiando $n...")
            copy(ctx, u, File(dir, n))
        }
        NexusLog.ok("${uris.size} OBB(s) adicionados")
        return uris.size
    }

    fun launch(pkg: String, user: Int = 0): Boolean {
        NexusLog.i("Abrindo $pkg (perfil $user)...")
        NexusLog.e("Motor de virtualização ausente: não é possível iniciar o jogo nesta versão")
        return false
    }

    fun clearData(pkg: String) {
        NexusLog.i("Sem motor: nada para limpar em $pkg")
    }

    fun remove(ctx: Context, g: Game) {
        apk(ctx, g.pkg).delete(); File(ctx.getExternalFilesDir(null), "obb/${g.pkg}").deleteRecursively()
        NexusLog.i("Removido: ${g.name}")
    }
}
