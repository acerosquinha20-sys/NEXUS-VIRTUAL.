package com.virtualnexus.app

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject

data class Game(
    val name: String, val pkg: String, val perms: List<String>,
    val obbs: Int = 0, val fav: Boolean = false, val launches: Int = 0,
    val last: Long = 0, val clones: Int = 0
)

object Prefs {
    var sound by mutableStateOf(true)
    var haptic by mutableStateOf(true)
    var anim by mutableStateOf(true)
    var accent by mutableStateOf(1)
    private fun sp(c: Context) = c.getSharedPreferences("nexus_prefs", 0)
    fun load(c: Context) { val s = sp(c); sound = s.getBoolean("sound", true); haptic = s.getBoolean("haptic", true); anim = s.getBoolean("anim", true); accent = s.getInt("accent", 1) }
    fun save(c: Context) = sp(c).edit().putBoolean("sound", sound).putBoolean("haptic", haptic).putBoolean("anim", anim).putInt("accent", accent).apply()
}

object Store {
    private fun sp(c: Context) = c.getSharedPreferences("nexus_games", 0)
    fun json(list: List<Game>): String = JSONArray().also { a -> list.forEach { g -> a.put(JSONObject()
        .put("n", g.name).put("p", g.pkg).put("pm", JSONArray(g.perms)).put("o", g.obbs)
        .put("f", g.fav).put("l", g.launches).put("t", g.last).put("c", g.clones)) } }.toString()
    fun save(c: Context, list: List<Game>) = sp(c).edit().putString("list", json(list)).apply()
    fun load(c: Context): List<Game> = runCatching {
        val a = JSONArray(sp(c).getString("list", "[]"))
        (0 until a.length()).map { val o = a.getJSONObject(it)
            Game(o.getString("n"), o.getString("p"), o.getJSONArray("pm").let { p -> (0 until p.length()).map { i -> p.getString(i) } },
                o.getInt("o"), o.getBoolean("f"), o.getInt("l"), o.getLong("t"), o.getInt("c")) }
    }.getOrDefault(emptyList())
}

object Fx {
    private var pool: SoundPool? = null
    private val ids = mutableMapOf<String, Int>()
    fun init(c: Context) {
        val p = SoundPool.Builder().setMaxStreams(4).setAudioAttributes(
            AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()).build()
        ids["click"] = p.load(c, R.raw.click, 1); ids["ok"] = p.load(c, R.raw.ok, 1)
        ids["err"] = p.load(c, R.raw.err, 1); ids["launch"] = p.load(c, R.raw.launch, 1)
        pool = p
    }
    fun play(n: String) { if (Prefs.sound) ids[n]?.let { pool?.play(it, 1f, 1f, 1, 0, 1f) } }
    fun buzz(c: Context, ms: Long = 15) {
        if (!Prefs.haptic) return
        c.getSystemService(Vibrator::class.java)?.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
    }
    fun tap(c: Context) { play("click"); buzz(c) }
    fun ok(c: Context) { play("ok"); buzz(c, 40) }
    fun err(c: Context) { play("err"); buzz(c, 90) }
}
